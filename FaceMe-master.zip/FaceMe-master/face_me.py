__author__ = 'kengarber'

import cv2
from pyflann import *
import numpy as np
import glob

images = glob.glob("faces/*.jpg")
cv2_images = []
for img in images:
    cv2_images.append(cv2.imread(img))
cv2_images_np = np.array(cv2_images)

cascPath = "haarcascade_frontalface_default.xml"
faceCascade = cv2.CascadeClassifier(cascPath)

video_capture = cv2.VideoCapture(0)

flann = FLANN()
params = flann.build_index(cv2_images_np)

while True:
    # Capture frame-by-frame
    ret, frame = video_capture.read()

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = faceCascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(30, 30),
        flags=cv2.CASCADE_SCALE_IMAGE
    )

    faces_cropped = []

    # Draw a rectangle around the faces
    for (x, y, w, h) in faces:
        cropped_face = frame[y: y + h, x: x + w]
        faces_cropped.append(cropped_face)
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 255), 2)

    faces_recognized = []
    for i in faces_cropped:
        result, dist = flann.nn_index(np.array(i), checks=params["checks"])
        print(result)
        # faces_recognized.append(flann.nn(cv2_images_np, np.array(i)))

    # print(faces_found)

    # Display the resulting frame
    cv2.imshow('Video', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# When everything is done, release the capture
video_capture.release()
cv2.destroyAllWindows()